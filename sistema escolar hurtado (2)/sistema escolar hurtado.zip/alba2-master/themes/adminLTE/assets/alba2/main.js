// button style
$('.btn').addClass('btn-sm');
