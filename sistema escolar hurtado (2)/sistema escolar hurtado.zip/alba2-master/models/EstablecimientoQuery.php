<?php
namespace app\models;

use yii\db\ActiveQuery;

class EstablecimientoQuery extends ActiveQuery
{
    /*
    public function active($state = true)
    {
        $this->andWhere(['active' => $state]);
        return $this;
    }
    */ 
}
