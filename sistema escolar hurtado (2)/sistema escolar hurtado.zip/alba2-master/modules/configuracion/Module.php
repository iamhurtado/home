<?php

namespace app\modules\configuracion;

use yii\base\BootstrapInterface;


class Module extends \yii\base\Module
{
	public $controllerNamespace = 'app\modules\configuracion\controllers';

	public function init()
	{
		parent::init();

		// custom initialization code goes here
	}
}
