<?php

namespace app\modules\portal;


class Module extends \yii\base\Module
{
	public $controllerNamespace = 'app\modules\portal\controllers';

	public function init()
	{
		parent::init();

		// custom initialization code goes here
	}
}
